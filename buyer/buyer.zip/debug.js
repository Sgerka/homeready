const index = require('./index');

let e = {
    'resource': '/newbuyer',
    'path': '/newbuyer',
    'httpMethod': 'POST',
    'headers': {
        'accept': '*/*',
        'accept-encoding': 'gzip, deflate, br',
        'accept-language': 'en-US,en;q=0.9',
        'content-type': 'application/json',
        'Host': 'lgi8tlgvtd.execute-api.us-east-1.amazonaws.com',
        'origin': 'https://homeready.webflow.io',
        'referer': 'https://homeready.webflow.io/',
        'sec-ch-ua': '" Not;A Brand";v="99", "Google Chrome";v="91", "Chromium";v="91"',
        'sec-ch-ua-mobile': '?1',
        'sec-fetch-dest': 'empty',
        'sec-fetch-mode': 'cors',
        'sec-fetch-site': 'cross-site',
        'User-Agent': 'Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.77 Mobile Safari/537.36',
        'X-Amzn-Trace-Id': 'Root=1-60c12595-036e9c597479c20822abfda8',
        'X-Forwarded-For': '5.29.28.246',
        'X-Forwarded-Port': '443',
        'X-Forwarded-Proto': 'https'
    },
    'multiValueHeaders': {
        'accept': ['*/*'],
        'accept-encoding': ['gzip, deflate, br'],
        'accept-language': ['en-US,en;q=0.9'],
        'content-type': ['application/json'],
        'Host': ['lgi8tlgvtd.execute-api.us-east-1.amazonaws.com'],
        'origin': ['https://homeready.webflow.io'],
        'referer': ['https://homeready.webflow.io/'],
        'sec-ch-ua': ['" Not;A Brand";v="99", "Google Chrome";v="91", "Chromium";v="91"'],
        'sec-ch-ua-mobile': ['?1'],
        'sec-fetch-dest': ['empty'],
        'sec-fetch-mode': ['cors'],
        'sec-fetch-site': ['cross-site'],
        'User-Agent': ['Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.77 Mobile Safari/537.36'],
        'X-Amzn-Trace-Id': ['Root=1-60c12595-036e9c597479c20822abfda8'],
        'X-Forwarded-For': ['5.29.28.246'],
        'X-Forwarded-Port': ['443'],
        'X-Forwarded-Proto': ['https']
    },
    'queryStringParameters': null,
    'multiValueQueryStringParameters': null,
    'pathParameters': null,
    'stageVariables': null,
    'requestContext': {
        'resourceId': 'mwmh55',
        'resourcePath': '/newbuyer',
        'httpMethod': 'POST',
        'extendedRequestId': 'ArLPWFHbIAMFtTQ=',
        'requestTime': '09/Jun/2021:20:33:25 +0000',
        'path': '/test/newbuyer',
        'accountId': '191251178836',
        'protocol': 'HTTP/1.1',
        'stage': 'test',
        'domainPrefix': 'lgi8tlgvtd',
        'requestTimeEpoch': 1623270805255,
        'requestId': 'e0f3687e-7290-4cca-a9b2-29315021325e',
        'identity': {
            'cognitoIdentityPoolId': null,
            'accountId': null,
            'cognitoIdentityId': null,
            'caller': null,
            'sourceIp': '5.29.28.246',
            'principalOrgId': null,
            'accessKey': null,
            'cognitoAuthenticationType': null,
            'cognitoAuthenticationProvider': null,
            'userArn': null,
            'userAgent': 'Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.77 Mobile Safari/537.36',
            'user': null
        },
        'domainName': 'lgi8tlgvtd.execute-api.us-east-1.amazonaws.com',
        'apiId': 'lgi8tlgvtd'
    },
    'body': '{"name": "קדר","Phone": "972508723111","Project": "example","seller": "d-rvtshtyyn"}',
    'isBase64Encoded': false
};
index.handler(e);


